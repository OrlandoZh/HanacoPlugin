# LLM Wiki Viewer

Hana plugin for an integrated `llm-wiki` skill. This v1.16 is a reliable helper and diagnostics console, not a full llm-wiki GUI.

## What It Does

- Builds `wiki/graph-data.json` and `wiki/knowledge-graph.html`.
- Serves the graph inside Hana and rewrites node source links to open local Markdown through plugin routes.
- Reports llm-wiki root status.
- Runs the mechanical lint report.
- Previews low-risk lint fixes with `lint-fix.sh --dry-run` without modifying files.
- Initializes a Chinese or English llm-wiki root.
- Runs source signal coverage and eligibility diagnostics.
- Reports read-only runtime context status for skill layout and optional adapter roots.
- Runs read-only diagnostics for wiki counts, source registry, and optional adapter state.
- Runs safety diagnostics for delete dry-run references, broken/orphan links, and graph `source_path` coverage.
- Provides source registry lookup/match helpers plus low-risk adapter/cache/Step 1 validation diagnostics for agents.
- Previews `create-source-page.sh` contract checks without writing source pages or updating cache.
- Can hand knowledge-base context startup, generation, update, query, digest, maintenance, and crystallize tasks to Hana Agent through Hana's native `session:create` and `session:send` bus capabilities.
- Shows `purpose.md` and Mermaid graph status, plus read-only source image and source/cache contract diagnostics.
- Adds graph contract diagnostics that summarize graph-data, graph HTML, `source_path`, link, long-label, isolated-node, and source overlap signals.
- Adds maintenance diagnostics for orphan sources/raw files, missing `source_path`, broken raw files, stale cache entries, source frontmatter gaps, missing source signals, query/digest index gaps, duplicate titles, and `purpose.md` quality hints.
- Carries selected upstream graph HTML regression contracts into the plugin test suite.

Content-heavy workflows such as ingest, query, digest, delete, and crystallize remain agent/skill-led. The plugin provides script-backed or read-only tools and a lightweight console for those workflows to lean on.

The viewer's collapsible `Agent 工作流` panel is opened from the top robot icon button and does not call model providers directly. It reads Hana agents via `agent:list`, can create a detached public workflow session via `session:create`, and sends a structured llm-wiki task prompt via `session:send`. The default delivery mode is `新建会话`, which avoids polluting an existing chat context. Users can still switch to `发送到已有会话` when they intentionally want to continue a selected session from `session:list`.

The `启动知识库上下文` action is the Hana-native replacement for the reference project's Claude `SessionStart` hook: it sends the current `wikiRoot`, `purpose.md`, `.wiki-schema.md`, and `index.md` context to a new or explicitly selected Hana session. It is not a background agent and does not call a model provider directly from the plugin.

Agent handoff prompts ask the selected Hana Agent to prioritize `purpose.md` and to tell the user to click `生成/刷新` after content changes. The plugin still does not perform content generation or maintenance writes itself.

Agent handoff diagnostics show a Chinese delivery summary with action, target session, accepted state, next step, and the full prompt. The viewer also keeps the latest prompt available through `复制 Prompt` so users can manually paste it into a Hana session when the bus is busy or unavailable.

Adapter diagnostics are visibility-only: the plugin does not install adapters, run upstream `install.sh` or `setup.sh`, repair dependencies, or perform automatic extraction.

`llm_wiki_init` is intentionally conservative: it only initializes a missing path or an empty directory. It returns `already_initialized` when `.wiki-schema.md` already exists and `target_not_empty` when the target contains unrelated files.

`llm_wiki_cache_status` is intentionally read-only. It mirrors the cache status calculation without invoking cache repair, update, or invalidate behavior.

`llm_wiki_lint_fix_preview` and `llm_wiki_source_page_contract_preview` are preview-only. They do not write wiki pages, update cache, or apply lint fixes.

## Tools

- `llm_wiki_status({ wikiRoot })`
- `llm_wiki_init({ wikiRoot, topic, language })`
- `llm_wiki_lint({ wikiRoot })`
- `llm_wiki_lint_fix_preview({ wikiRoot })`
- `llm_wiki_build_graph({ wikiRoot })`
- `llm_wiki_maintenance_diagnostics({ wikiRoot })`
- `llm_wiki_source_coverage({ wikiRoot })`
- `llm_wiki_source_signal_eligibility({ wikiRoot })`
- `llm_wiki_runtime_context_status({ wikiRoot })`
- `llm_wiki_source_image_diagnostics({ wikiRoot })`
- `llm_wiki_source_contract_diagnostics({ wikiRoot })`
- `llm_wiki_diagnostics({ wikiRoot })`
- `llm_wiki_source_registry({})`
- `llm_wiki_adapter_status({ sourceId })`
- `llm_wiki_delete_dry_run({ wikiRoot, sourceFile })`
- `llm_wiki_link_diagnostics({ wikiRoot })`
- `llm_wiki_graph_source_paths({ wikiRoot })`
- `llm_wiki_source_get({ sourceId })`
- `llm_wiki_source_match_url({ url })`
- `llm_wiki_source_match_file({ filePath })`
- `llm_wiki_adapter_classify({ sourceId, exitCode, outputPath })`
- `llm_wiki_cache_status({ wikiRoot, filePath })`
- `llm_wiki_source_page_contract_preview({ wikiRoot, rawFile, outputPath, contentFile })`
- `llm_wiki_validate_step1({ jsonFile })`

Each tool returns `content` plus a structured `details` object with `ok`, `wikiRoot`, `stdout`, `stderr`, `code`, `error`, and `status` where relevant.

In Hana's model-visible tool list these are prefixed by the plugin id, for example `llm-wiki-viewer_llm_wiki_status`. Plugin action calls and dev tool invocation still use the unprefixed action ids listed above.

## Page

The contributed page is `/viewer`. It keeps the graph as the main view and adds:

- wikiRoot input with saved-location dropdown
- explicit save-location action for first use and later switching
- status summary
- graph build/refresh
- lint output
- source coverage output
- source signal eligibility and runtime context summaries inside diagnostics output
- diagnostics output
- safety diagnostics and delete dry-run references
- graph contract diagnostics inside the diagnostics output
- source image and source/cache contract diagnostics
- maintenance diagnostics for orphan sources/raw files, duplicate titles, raw/cache/frontmatter/source signal issues, query/digest index gaps, and `purpose.md` hints
- init controls
- Collapsible top robot-button Agent workflow controls with default new-session delivery, optional existing-session delivery, Chinese templates, delivery summary, and `复制 Prompt` fallback
- latest stdout/stderr log

## Configuration

`defaultWikiRoot` may point to an initialized llm-wiki root containing `.wiki-schema.md` and `wiki/`.

`savedWikiRoots` stores recently saved wiki roots for the viewer dropdown. On first use, enter or paste a wiki root path in the top location field and click `生成/刷新`; the plugin safely initializes missing or empty locations before building the graph. Successful init/build actions also save the current location.

This Hana integration does not run upstream `install.sh` or `setup.sh`. Optional URL extraction adapters should be handled by the skill/agent workflow or configured externally.

## Manual Acceptance

- Open `/viewer` in Hana with a real `wikiRoot`.
- Confirm first-use path entry can be saved and later selected from the top location dropdown.
- Confirm the `open-viewer` dev scenario opens the contributed page.
- Confirm all 24 `llm-wiki-viewer_llm_wiki_*` tools are discoverable by the Hana agent, including lint-fix preview, source page contract preview, source signal eligibility, runtime context, maintenance diagnostics, source lookup/match, adapter classify, cache status, and Step 1 validation.
- Confirm `/api/diagnostics` reports wiki counts, source coverage summary, adapter summary, and graph contract summary.
- Confirm `/api/source-signal-eligibility` and `/api/runtime-context` report read-only source signal and skill layout diagnostics.
- Confirm `/api/lint-fix-preview` and `/api/source-page-contract-preview` report preview results without mutating wiki content.
- Confirm `/api/maintenance-diagnostics` reports orphan sources/raw files, source_path/raw/cache/frontmatter/source signal issues, query/digest index gaps, duplicate titles, and `purpose.md` hints without mutating wiki content.
- Confirm `/api/link-diagnostics`, `/api/graph-source-paths`, and `/api/delete-dry-run` return readable safety diagnostics and never mutate wiki content.
- Confirm `/api/source-image-diagnostics` and `/api/source-contract-diagnostics` report read-only source issues.
- Confirm `/api/agents`, `/api/sessions`, and `/api/agent-send` can list Hana agents/sessions and hand a llm-wiki task to a new or selected session.
- Confirm the top robot icon expands/collapses the Agent workflow panel without sending anything by itself.
- Confirm selecting `启动知识库上下文` with `新建会话` creates a separate Hana session and sends the current wiki context without requiring task input.
- Confirm switching to `发送到已有会话` appends the task only to the explicitly selected Hana session.
- Confirm Agent output shows action, target session, accepted state, next step, and full prompt; `复制 Prompt` copies the latest prompt for manual fallback.
- Confirm the plugin test suite includes selected upstream graph HTML contract checks and graph build failure handling.
- Confirm `purpose.md` and Mermaid graph status appear in the viewer status area.
- Confirm build refreshes the iframe graph and graph node source links open Markdown through `/wiki-file/*`.
- Confirm non-wiki roots disable build/lint/coverage and keep init available.
